import {
  StatsSummary,
  HourlyStat,
  TopBlockedDomain,
  DNSQuery,
  BlocklistEntry,
  WhitelistEntry,
  DomainAnalyzeResult,
  TunnelIncident
} from '../types';

const BASE_URL = 'http://localhost:8000';

async function fetchAPI<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });
  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }
  return response.json();
}

export const getStatsSummary = () => fetchAPI<StatsSummary>('/api/stats/summary');
export const getHourlyStats = () => fetchAPI<HourlyStat[]>('/api/stats/hourly');
export const getTopBlocked = (limit = 10) => fetchAPI<TopBlockedDomain[]>(`/api/stats/top-blocked?limit=${limit}`);
export const getRecentQueries = (params?: Record<string, any>) => {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return fetchAPI<DNSQuery[]>(`/api/queries${qs}`);
};
export const getBlocklist = () => fetchAPI<BlocklistEntry[]>('/api/blocklist');
export const addToBlocklist = (domains: string[], reason: string) => fetchAPI<any>('/api/blocklist', {
  method: 'POST',
  body: JSON.stringify({ domains, reason })
});
export const deleteFromBlocklist = (id: number) => fetchAPI<any>(`/api/blocklist/${id}`, { method: 'DELETE' });

export const getWhitelist = () => fetchAPI<WhitelistEntry[]>('/api/whitelist');
export const addToWhitelist = (domains: string[], reason: string) => fetchAPI<any>('/api/whitelist', {
  method: 'POST',
  body: JSON.stringify({ domains, reason })
});
export const deleteFromWhitelist = (id: number) => fetchAPI<any>(`/api/whitelist/${id}`, { method: 'DELETE' });

export const analyzeDomain = (domain: string) => fetchAPI<DomainAnalyzeResult>(`/api/analyze?domain=${encodeURIComponent(domain)}`);

export const getTunnelIncidents = (status?: string) => {
  const qs = status ? `?status=${status}` : '';
  return fetchAPI<TunnelIncident[]>(`/api/tunnel-incidents${qs}`);
};
export const updateTunnelIncident = (id: number, status: string) => fetchAPI<any>(`/api/tunnel-incidents/${id}`, {
  method: 'PUT',
  body: JSON.stringify({ status })
});

export const getSettings = () => fetchAPI<any>('/api/settings');
export const updateSettings = (data: any) => fetchAPI<any>('/api/settings', {
  method: 'PUT',
  body: JSON.stringify(data)
});
