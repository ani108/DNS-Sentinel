# Tests init
