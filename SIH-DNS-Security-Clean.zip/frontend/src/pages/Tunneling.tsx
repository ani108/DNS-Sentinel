export default function Tunneling() {
  return <div><h1 className="text-2xl font-bold">Tunnel Monitor</h1></div>;
}
