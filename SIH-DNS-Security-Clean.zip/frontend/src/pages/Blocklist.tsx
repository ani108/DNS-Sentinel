export default function Blocklist() {
  return <div><h1 className="text-2xl font-bold">Rules & Lists</h1></div>;
}
